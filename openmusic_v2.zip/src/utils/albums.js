const mapAlbums = ({
    id,
    name,
    year,
}) => ({
    id,
    name,
    year,
});

module.exports = { mapAlbums };
